import React from 'react'
import Collection from './JSX/Collection'
import Navbar from '../Home/JSX/Navbar'
import Footer from '../Home/JSX/Footer'
import { useParams } from 'react-router'


const Shop = () => {
  const { category } = useParams()
  return (
    <div>
      
        <Navbar/>
        <Collection category={category}/>
        <Footer/>
        
    </div>
  )
}

export default Shop
